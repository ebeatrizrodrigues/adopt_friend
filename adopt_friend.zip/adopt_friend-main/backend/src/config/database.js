module.exports = {
    dialect:'mysql',
    host: 'localhost',
    username: 'root',
    password: 'sua_senha',
    database : 'seu_db',
    define: {
        timestamp: true, 
        underscored: true, 
        underscoredAll: true,
    },
};