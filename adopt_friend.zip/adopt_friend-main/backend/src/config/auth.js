export default {
    secret: 'eab74983ac9f0ec0ed750f7186981bfc',
    expiresIn: '9999s'
};