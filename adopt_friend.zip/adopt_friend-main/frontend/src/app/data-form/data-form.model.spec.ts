import { DataForm } from './data-form.model';

describe('DataForm', () => {
  it('should create an instance', () => {
    expect(new DataForm()).toBeTruthy();
  });
});
