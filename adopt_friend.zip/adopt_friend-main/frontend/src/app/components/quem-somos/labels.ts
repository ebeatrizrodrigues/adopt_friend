export const labels = {
    howWeAre: `
        Somos uma ONG com trabalhos 100% filantrópicos voltados para
        diminuir o sofrimento animal com foco em câes e
        gatos sujeitos ao abandono ou em situação de risco
        em todo o Brasil.
    `,
    whatWeDo: `Atuamos com o objetivo de promover a conexão de
        animais em situação de vulnerabilidades, criando projetos,
        estruturas, mecânismos e ferramentas que auxiliem o trabalho
        voltado para causa animal.`,
    
        
    projects: `- O sistema para capacitação de recursos ( e-commerce, Google e
        espaços publicitários ) para pagar mão de obra, divulgação em ônibus,
        outdoor, jornais , despesas dos projetos AUA e etc..`    
}   