import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-endereco',
  templateUrl: './endereco.component.html',
  styleUrls: ['./endereco.component.less']
})
export class EnderecoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
