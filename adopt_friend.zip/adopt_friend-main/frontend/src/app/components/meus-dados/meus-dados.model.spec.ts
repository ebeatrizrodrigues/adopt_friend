import { MeusDados } from './meus-dados.model';

describe('MeusDados', () => {
  it('should create an instance', () => {
    expect(new MeusDados()).toBeTruthy();
  });
});
