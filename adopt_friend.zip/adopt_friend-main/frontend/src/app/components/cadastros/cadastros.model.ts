export interface Cadastros {
    id?: number,
    name: string,
    cpf: string,
    email: string,
    phone: string,
    password:string,
    confirmPassword:string
}
